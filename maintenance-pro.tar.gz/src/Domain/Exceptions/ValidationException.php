<?php
declare(strict_types=1);

namespace MaintenancePro\Domain\Exceptions;

class ValidationException extends \InvalidArgumentException
{
    // You can add custom properties or methods here if needed in the future.
}