<?php
declare(strict_types=1);

namespace MaintenancePro\Infrastructure\Health;

use MaintenancePro\Domain\Contracts\CacheInterface;
use MaintenancePro\Domain\ValueObjects\HealthStatusValue;
use MaintenancePro\Infrastructure\FileSystem\FileSystemProvider;

/**
 * Performs a health check on the available disk space for a given path.
 *
 * This check is critical because a full disk can lead to application-wide failures,
 * including the inability to write logs, cache files, or session data.
 * The result of this check is cached to improve performance.
 */
class DiskSpaceHealthCheck implements HealthCheckInterface
{
    private const CACHE_KEY = 'health_check.disk_space';
    private const CACHE_TTL = 300; // 5 minutes

    private string $path;
    private float $warningThreshold;
    private CacheInterface $cache;
    private FileSystemProvider $fileSystemProvider;

    /**
     * @param string $path The path to check for disk space (e.g., '/var/www').
     * @param CacheInterface $cache The cache service to store the result.
     * @param FileSystemProvider $fileSystemProvider The file system provider.
     * @param float $warningThreshold The usage percentage at which to trigger a warning (e.g., 90.0 for 90%).
     */
    public function __construct(
        string $path,
        CacheInterface $cache,
        FileSystemProvider $fileSystemProvider,
        float $warningThreshold = 90.0
    ) {
        $this->path = $path;
        $this->cache = $cache;
        $this->fileSystemProvider = $fileSystemProvider;
        $this->warningThreshold = $warningThreshold;
    }

    /**
     * {@inheritdoc}
     */
    public function check(): HealthStatusValue
    {
        $cachedStatus = $this->cache->get(self::CACHE_KEY);
        if ($cachedStatus instanceof HealthStatusValue) {
            return $cachedStatus;
        }

        if (!is_dir($this->path) || !is_readable($this->path)) {
            $status = HealthStatusValue::unhealthy("Path '{$this->path}' is not a readable directory.");
            $this->cache->set(self::CACHE_KEY, $status, self::CACHE_TTL);
            return $status;
        }

        $free = $this->fileSystemProvider->getFreeSpace($this->path);
        $total = $this->fileSystemProvider->getTotalSpace($this->path);

        if ($total === false || $free === false) {
            $status = HealthStatusValue::unhealthy("Could not determine disk space for path '{$this->path}'. Check permissions.");
            $this->cache->set(self::CACHE_KEY, $status, self::CACHE_TTL);
            return $status;
        }

        $used = $total - $free;
        $usedPercent = $total > 0 ? ($used / $total) * 100 : 0;

        $details = [
            'path' => $this->path,
            'total_space' => $this->formatBytes($total),
            'used_space' => $this->formatBytes($used),
            'free_space' => $this->formatBytes($free),
            'used_percent' => round($usedPercent, 2),
            'threshold_percent' => $this->warningThreshold,
        ];

        if ($usedPercent > $this->warningThreshold) {
            $message = sprintf(
                'Disk space usage is critical: %.2f%% used, exceeds threshold of %.2f%%.',
                $usedPercent,
                $this->warningThreshold
            );
            $status = HealthStatusValue::unhealthy($message, $details);
        } else {
            $message = sprintf(
                'Disk space is OK: %.2f%% used.',
                $usedPercent
            );
            $status = HealthStatusValue::healthy($message, $details);
        }

        $this->cache->set(self::CACHE_KEY, $status, self::CACHE_TTL);
        return $status;
    }

    /**
     * {@inheritdoc}
     */
    public function getName(): string
    {
        return 'disk_space';
    }

    /**
     * {@inheritdoc}
     */
    public function isCritical(): bool
    {
        return true;
    }

    /**
     * Formats a number of bytes into a human-readable string.
     *
     * @param float $bytes The number of bytes.
     * @return string The formatted string (e.g., '1.23 GB').
     */
    private function formatBytes(float $bytes): string
    {
        if ($bytes <= 0) {
            return '0 B';
        }

        $units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
        $power = floor(log($bytes, 1024));
        $power = min($power, count($units) - 1);

        return sprintf('%.2f', $bytes / pow(1024, $power)) . ' ' . $units[$power];
    }
}